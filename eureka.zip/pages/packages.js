const Packages = () => {
  return <div>PACKAGES</div>
}

export default Packages;