(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 2813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "aos"
const external_aos_namespaceObject = require("aos");
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_namespaceObject);
// EXTERNAL MODULE: ./node_modules/aos/dist/aos.css
var aos = __webpack_require__(1759);
// EXTERNAL MODULE: ./styles/bootstrap.min.css
var bootstrap_min = __webpack_require__(2620);
// EXTERNAL MODULE: ./styles/animate.css
var animate = __webpack_require__(9687);
// EXTERNAL MODULE: ./styles/meanmenu.css
var meanmenu = __webpack_require__(3927);
// EXTERNAL MODULE: ./styles/boxicons.min.css
var boxicons_min = __webpack_require__(7851);
// EXTERNAL MODULE: ./styles/flaticon.css
var flaticon = __webpack_require__(8628);
// EXTERNAL MODULE: ./node_modules/react-modal-video/css/modal-video.min.css
var modal_video_min = __webpack_require__(4562);
// EXTERNAL MODULE: ./node_modules/react-accessible-accordion/dist/fancy-example.css
var fancy_example = __webpack_require__(7600);
// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(5994);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(8722);
// EXTERNAL MODULE: ./node_modules/swiper/swiper-bundle.min.css
var swiper_bundle_min = __webpack_require__(1631);
// EXTERNAL MODULE: ./styles/style.css
var style = __webpack_require__(8702);
// EXTERNAL MODULE: ./styles/responsive.css
var responsive = __webpack_require__(6050);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: ./components/_App/GoTop.js


class GoTop extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            is_visible: false
        };
    }
    componentDidMount() {
        var scrollComponent = this;
        document.addEventListener("scroll", function(e) {
            scrollComponent.toggleVisibility();
        });
    }
    toggleVisibility() {
        if (window.pageYOffset > 300) {
            this.setState({
                is_visible: true
            });
        } else {
            this.setState({
                is_visible: false
            });
        }
    }
    scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }
    render() {
        const { is_visible  } = this.state;
        return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
            className: "scroll-to-top",
            children: is_visible && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "go-top",
                onClick: ()=>this.scrollToTop(),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "bx bx-chevrons-up"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "bx bx-chevrons-up"
                    })
                ]
            })
        });
    }
}

;// CONCATENATED MODULE: ./components/_App/Preloader.js


const Preloader = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "loader-wrapper",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "loader"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "loader-section section-left"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "loader-section section-right"
                })
            ]
        })
    });
};
/* harmony default export */ const _App_Preloader = (Preloader);

;// CONCATENATED MODULE: ./components/_App/Layout.js





const Layout = ({ children  })=>{
    // Preloader
    const [loader, setLoader] = external_react_default().useState(true);
    external_react_default().useEffect(()=>{
        setTimeout(()=>setLoader(false), 1500);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("title", {
                        children: "Corf - Doctor Medical Health React Next Template"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, shrink-to-fit=no"
                    })
                ]
            }),
            children,
            loader ? /*#__PURE__*/ (0,jsx_runtime_.jsx)(_App_Preloader, {}) : null,
            /*#__PURE__*/ (0,jsx_runtime_.jsx)(GoTop, {
                scrollStepInPx: "100",
                delayInMs: "10.50"
            })
        ]
    });
};
/* harmony default export */ const _App_Layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.js














// Global Styles



const MyApp = ({ Component , pageProps  })=>{
    external_react_default().useEffect(()=>{
        external_aos_default().init();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(_App_Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(Component, {
            ...pageProps
        })
    });
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 1759:
/***/ (() => {



/***/ }),

/***/ 7600:
/***/ (() => {



/***/ }),

/***/ 5994:
/***/ (() => {



/***/ }),

/***/ 4562:
/***/ (() => {



/***/ }),

/***/ 1631:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 9687:
/***/ (() => {



/***/ }),

/***/ 2620:
/***/ (() => {



/***/ }),

/***/ 7851:
/***/ (() => {



/***/ }),

/***/ 8628:
/***/ (() => {



/***/ }),

/***/ 3927:
/***/ (() => {



/***/ }),

/***/ 6050:
/***/ (() => {



/***/ }),

/***/ 8702:
/***/ (() => {



/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2813));
module.exports = __webpack_exports__;

})();