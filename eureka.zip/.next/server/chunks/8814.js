"use strict";
exports.id = 8814;
exports.ids = [8814];
exports.modules = {

/***/ 8814:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Common_NewsStyleOne)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Common/SingleBlog.js


const SingleBlog = ({ blog  })=>{
    const { id , title , thumbnail  } = blog;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "single-blog",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)((link_default()), {
                href: `/blogs/${id}`,
                className: "blog-thumbnail",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("img", {
                    src: thumbnail,
                    alt: "Image"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                children: "11 May 2020"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-content",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((link_default()), {
                                href: "#",
                                children: "Treatment"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)((link_default()), {
                        href: `/blogs/${id}`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("h3", {
                            children: title
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: `/blogs/${id}`,
                        className: "read-more",
                        children: [
                            "Read More ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                                className: "bx bx-plus"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Common_SingleBlog = (SingleBlog);

// EXTERNAL MODULE: ./data/data.js
var data = __webpack_require__(7918);
;// CONCATENATED MODULE: ./components/Common/NewsStyleOne.js





const NewsStyleOne = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
            className: "blog-area pt-100 pb-70",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "section-title",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                                className: "top-title",
                                children: "News"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("h2", {
                                children: "Our Latest News"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "row justify-content-center",
                        children: data/* blogs.map */.Z.map((blog)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(Common_SingleBlog, {
                                    blog: blog
                                })
                            }, blog.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Common_NewsStyleOne = (NewsStyleOne);


/***/ }),

/***/ 7918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ blogs)
/* harmony export */ });
const blogs = [
    {
        id: 1,
        title: "SPEECH AT STRATOSPHERE HOTEL & CASINO CONVENTION HALL IN LAS VEGAS USA 2014",
        thumbnail: "/img/blog-one.jpg",
        content: "My Speech At Stratosphere Hotel & Casino Convention Hall In LAS VEGAS USA 2014"
    },
    {
        id: 2,
        title: "BEST QUALITY LEADERSHIP AWARD FROM DAVID BREDFORD OF EUROPEAN SOCIETY FOR QUALITY RESEARCH (ESQR)",
        thumbnail: "/img/blog-two.jpg",
        content: "LAST NIGHT RECEIVING BEST QUALITY LEADERSHIP AWARD FROM DAVID BREDFORD OF EUROPEAN SOCIETY FOR QUALITY RESEARCH (ESQR)"
    },
    {
        id: 3,
        title: "NEWS ON ITTAFAK",
        thumbnail: "/img/blog-three.jpg",
        content: ""
    }
];


/***/ })

};
;