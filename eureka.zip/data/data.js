export const blogs = [
  {
    id: 1,
    title:
      "SPEECH AT STRATOSPHERE HOTEL & CASINO CONVENTION HALL IN LAS VEGAS USA 2014",
    thumbnail: "/img/blog-one.jpg",
    content: "My Speech At Stratosphere Hotel & Casino Convention Hall In LAS VEGAS USA 2014"
  },
  {
    id: 2,
    title:
      "BEST QUALITY LEADERSHIP AWARD FROM DAVID BREDFORD OF EUROPEAN SOCIETY FOR QUALITY RESEARCH (ESQR)",
    thumbnail: "/img/blog-two.jpg",
    content: 'LAST NIGHT RECEIVING BEST QUALITY LEADERSHIP AWARD FROM DAVID BREDFORD OF EUROPEAN SOCIETY FOR QUALITY RESEARCH (ESQR)'
  },
  { id: 3, title: "NEWS ON ITTAFAK", thumbnail: "/img/blog-three.jpg", content: "" },
];
